package players;

public class PieceO extends PlayerPiece{

    public PieceO(PieceType type){
        super(type);
    }
}
