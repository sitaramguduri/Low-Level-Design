package players;

public enum PieceType {
    X,
    O
}
