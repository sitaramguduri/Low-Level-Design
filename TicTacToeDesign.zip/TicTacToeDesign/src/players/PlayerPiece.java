package players;

public abstract class PlayerPiece {
    PieceType type;
    PlayerPiece(PieceType type){
        this.type = type;
    }

}
