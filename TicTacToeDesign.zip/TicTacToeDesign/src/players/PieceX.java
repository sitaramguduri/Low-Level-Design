package players;

public class PieceX extends PlayerPiece{

    public PieceX(PieceType type){
        super(type);
    }
}
