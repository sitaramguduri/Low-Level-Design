import players.Player;
import tictactoe.TicTacToeGame;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        TicTacToeGame game = new TicTacToeGame();
        game.intializeGame();
        game.startGame();

    }
}