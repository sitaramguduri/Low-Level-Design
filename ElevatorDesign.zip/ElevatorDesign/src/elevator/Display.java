package elevator;

public class Display {
    public void display(int floor){
        System.out.println(" Display the current floor" + floor);
    }
}
