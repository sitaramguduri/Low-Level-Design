package elevator;

import enums.Direction;

import java.util.List;

public class ExternalButtonDispatcher {
    private List<ElevatorCarController> controllerList;

    public ExternalButtonDispatcher(List<ElevatorCarController> controllerList){
        this.controllerList = controllerList;
    }
    // we need to have different strategies here to decide which lift controller should get the request.
    public void pressButton(int currentFloor, Direction direction){
        for(ElevatorCarController elevatorCarController: controllerList){
            int elevatorID = elevatorCarController.getLiftId();
            if(elevatorID %2 == 1 & currentFloor%2 == 1 ){
                elevatorCarController.sendExternalRequest(currentFloor, direction);
            }else{
                elevatorCarController.sendExternalRequest(currentFloor, direction);
            }
        }
    }
}
