package elevator;

public class Door {
    public void openDoor(){
        System.out.println("Opens Door");
    }
    public void closeDoor(){
        System.out.println("Closes the Door");
    }
    
}
