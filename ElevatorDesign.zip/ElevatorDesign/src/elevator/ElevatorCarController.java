package elevator;

import enums.Direction;

import java.util.PriorityQueue;

public class ElevatorCarController {

    ElevatorCar car;
    PriorityQueue<Integer> minHeap = new PriorityQueue<>();

    PriorityQueue<Integer> maxHeap = new PriorityQueue<>();
    public ElevatorCarController(ElevatorCar car){
        this.car = car;
    }
    public int getLiftId(){
        return car.getId();
    }
    public void moveElevatorCar( int floor){
        if(car.getCurrentFloor() < floor){
            //has to move up for this request so add it to the minHeap;
            minHeap.add(floor);
        } else if (car.getCurrentFloor() > floor) {
            maxHeap.add(floor);
        }else{
            //on the same floor
        }
    }
    public void sendNewRequest(int floor){
        // check the direction of the elevator and its current
        // floor and assign the new request floor to either minHeap or MaxHeap

        if(car.getDirection() == Direction.NOTMOVING){
            //we need to check the current floor and if we want the
            // lift to move up add it to the minHeap else add it to the maxHeap
            moveElevatorCar(floor);
            controlCar();
        }else if (car.getDirection() == Direction.UP){
            moveElevatorCar(floor);

        }else{
            moveElevatorCar(floor);

        }
        // after the addition of min and
        // max heap we need to move the elevator to either up or down when the elevator is not moving
        // if it is moving we need to make sure that when its corresponding priority queue
        // is empty then we move it in opposite directon
    }
    public void controlCar(){
        // control the car depending on the min and max Heap
        if(car.getDirection() == Direction.NOTMOVING){
            // we need to make it start moving
            if(!minHeap.isEmpty()){
                // we need to make it move up
                while(!minHeap.isEmpty()){
                    car.move(Direction.UP, minHeap.poll());
                }
            }
            if(!maxHeap.isEmpty()){
                while(!maxHeap.isEmpty()){
                    car.move(Direction.DOWN, maxHeap.poll());
                }
            }

        }
    }
    public void sendExternalRequest(int requestFloor, Direction direction){
        // ask the lift to come to this floor and you want to go towards the direction
        System.out.println("requestFloor: " + requestFloor + " direction: " + direction);
        if(direction == Direction.UP){
            if(direction == car.getDirection()){
                if(car.getCurrentFloor() > requestFloor){
                    maxHeap.add(requestFloor);
                }else{
                    minHeap.add(requestFloor);
                }
            }else{
                minHeap.add(requestFloor);
            }
        }else if(direction == Direction.DOWN){
            if(direction == car.getDirection()){
                if(car.getCurrentFloor() > requestFloor){
                    maxHeap.add(requestFloor);
                }else{
                    minHeap.add(requestFloor);
                }
            }else{
                maxHeap.add(requestFloor);
            }
        }else{
            if(direction == Direction.UP){
                minHeap.add(requestFloor);
            }else{
                maxHeap.add(requestFloor);
            }
        }

        controlCar();
    }

}
