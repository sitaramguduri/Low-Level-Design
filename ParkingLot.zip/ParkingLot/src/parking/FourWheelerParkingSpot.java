package parking;

public class FourWheelerParkingSpot extends ParkingSpot{
    public FourWheelerParkingSpot(int id){
        super(id);
        this.price = 50;
    }
}
