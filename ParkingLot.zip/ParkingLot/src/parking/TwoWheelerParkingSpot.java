package parking;

public class TwoWheelerParkingSpot extends ParkingSpot{
    public TwoWheelerParkingSpot(int id){

        super(id);
        this.price = 10;
    }
}
