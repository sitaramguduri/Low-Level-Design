package Types;

public enum VehicleType {
    TWO,
    FOUR
}
